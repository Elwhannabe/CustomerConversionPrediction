# Welcome! 👋

I'm @Elwhannabe, a passionate and aspiring desktop engineer with a strong foundation in help desk support. I'm enthusiastic about technology and continuously exploring new areas to enhance my skills.

## 👀 Interests
- Technology and innovation
- Machine learning and data science
- System administration and automation
- Open-source projects and collaboration

## 🌱 Currently Learning
- Advanced desktop engineering techniques
- Machine learning for customer conversion prediction
- Version control with Git and GitHub

## 💞️ Looking to Collaborate On
- Desktop engineering projects
- Machine learning models and data science projects
- Open-source tools and utilities for system administration

## 📫 How to Reach Me
- LinkedIn: linkedin.com/in/eduardomarquez05
- Email: eamarquez05@yahoo.com
  
## 😄 Pronouns
- He/Him
  
## ⚡ Fun Fact
- I have a knack for solving tech puzzles and love to tinker with new gadgets and software!

